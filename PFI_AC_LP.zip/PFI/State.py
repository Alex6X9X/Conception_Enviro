#Auteurs: Alexandre Carle et Louis-philippe Rousseau
#Dernier changement 19 décembre 2022

from enum import Enum
class State(Enum):
    Immobile = 0
    Translation = 1
    Rotation = 2