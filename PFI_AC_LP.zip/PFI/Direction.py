#Auteurs: Alexandre Carle et Louis-philippe Rousseau
#Dernier changement 19 décembre 2022

from enum import Enum
class Direction(Enum):
    Gauche = 0
    Droite = 1