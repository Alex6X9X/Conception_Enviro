#Alexandre Carle et Louis-philippe Rousseau
#12 septembre 2022
#Dernier changement le 12 septembre 2022
def copier_tableau(tab):
        return tab.copy()